
DEFAULT_DATABASE = {
    {%- if database_engine == 'mysql' %}
    'ENGINE': 'django.db.backends.mysql',
    'PORT': '3306',
    'OPTIONS': { 'init_command': 'SET storage_engine=INNODB', },
    {% else %}
    'ENGINE': 'django.db.backends.postgresql_psycopg2',
    'PORT': '5432',
    {%- endif %}
    'HOST': '{{ database_host }}',
    'NAME': '{{ database_name }}',
    'PASSWORD': '{{ database_password }}',
    'USER': '{{ database_user }}'
}

DEFAULT_CACHE = {
    'BACKEND': 'django.core.cache.backends.memcached.MemcachedCache',
    'LOCATION': '{{ cache_host }}:11211',
    'TIMEOUT': 120,
    'KEY_PREFIX': '{{ cache_prefix }}'
}

DEFAULT_EMAIL = {
    'HOST': '{{ email_host }}',
    'USER': '{{ email_user }}',
    'PASSWORD': '{{ email_password }}'
}