#!/usr/bin/perl
use strict;
use Term::Menu;

my $serviceUsername = 'opensim';

my $EXIT = 1;

my $MainTitle = "+-----------------------------------------------------+\n";
$MainTitle .= "|        SCREEN Connection for OPENSIM Servers        |\n";
$MainTitle .= "|                                                     |\n";
$MainTitle .= "|    ( Type CTRL+A+D to exit the Screen Console. )    |\n";
$MainTitle .= "+-----------------------------------------------------+\n";

while ( $EXIT == 1 )
{

  system("screen -list | grep service > /tmp/osg.services");
  my %LIST = ();
  open(IN, "/tmp/osg.services");
  while ( my $i = <IN> )
  {
    chomp($i);

    $i =~ s/\./#/g;
    $i =~ s/\-service\t/#/g;
    $i =~ s/\t//g;
    $i =~ s/\(//g;
    $i =~ s/\)//g;

    my @STATUS = split(/#/, $i);
    $LIST{$STATUS[1]} = $STATUS[2];
  }
  close(IN);

  my %LIST2 = ();
  my @indices = ('User', 'Grid', 'Asset', 'Messaging', 'Region');

  foreach my $key ( @indices )
  {
    # print "$key --> $LIST{$key}\n";
    if ( $LIST{$key} =~ /Attached/ )
    {
      $LIST2{$key} = "[X]";
    }
    else
    {
      $LIST2{$key} = "[ ]";
    }
  }

  if ( $LIST{'User'} =~ /Attached/ )
  {
    $LIST2{'USER'} = "X";
  }
  else
  {
    $LIST2{'USER'} = "-";
  }

	system ('clear');
  my $prompt = new Term::Menu (
    spaces => 3,
    aftertext => "\nChoose an option : ",
    beforetext => ${MainTitle},
    delim => ". ",
  );

  my $SEP = "                   ";

  my $answer = $prompt->menu(
                osg_user       => ["OpenSimulator User Server       $SEP$LIST2{'User'}",  '1'],
                osg_grid       => ["OpenSimulator Grid Server       $SEP$LIST2{'Grid'}",  '2'],
                osg_asset      => ["OpenSimulator Asset Server      $SEP$LIST2{'Asset'}",  '3'],
                osg_messaging  => ["OpenSimulator Messaging Server  $SEP$LIST2{'Messaging'}",  '4'],
                osg_region     => ["OpenSimulator Region Server     $SEP$LIST2{'Region'}\n",  '5'],
                osg_shutdown   => ["Shutdown Servers (Manual)",'6'],
                osg_shutdown2  => ["Shutdown Servers (Hard)\n",'7'],
                quit    => ["Quit", 'q'],
                            );

  if ( "${answer}" eq "quit" )
  {
    $EXIT = 0;
  }

  if ( "${answer}" eq "osg_user" )
  {
    system("screen -d -r -A -S $serviceUsername/User-service");
    $EXIT = 1;
  }

  if ( "${answer}" eq "osg_grid" )
  {
    system("screen -d -r -A -S $serviceUsername/Grid-service");
    $EXIT = 1;
  }

  if ( "${answer}" eq "osg_asset" )
  {
    system("screen -d -r -A -S $serviceUsername/Asset-service");
    $EXIT = 1;
  }

  if ( "${answer}" eq "osg_messaging" )
  {
    system("screen -d -r -A -S $serviceUsername/Messaging-service");
    $EXIT = 1;
  }

  if ( "${answer}" eq "osg_region" )
  {
    system("screen -d -r -A -S $serviceUsername/Region-service");
    $EXIT = 1;
  }

if ( "${answer}" eq "osg_shutdown" )
  {
    system("screen -d -r -A -S $serviceUsername/Region-service");
    system("screen -d -r -A -S $serviceUsername/Messaging-service");
    system("screen -d -r -A -S $serviceUsername/Asset-service");
    system("screen -d -r -A -S $serviceUsername/Grid-service");
    system("screen -d -r -A -S $serviceUsername/User-service");
    $EXIT = 1;
  }

  if ( "${answer}" eq "osg_shutdown2" )
  {
    system("screen -S $serviceUsername/Region-service -r -m -X quit");
    system("screen -S $serviceUsername/Messaging-service -r -m -X quit");
    system("screen -S $serviceUsername/Asset-service -r -m -X quit");
    system("screen -S $serviceUsername/Grid-service -r -m -X quit");
    system("screen -S $serviceUsername/User-service -r -m -X quit");
    $EXIT = 0;
  }
}