#!/bin/bash

export MONO_THREADS_PER_CPU=150

cd /srv/opensim/bin

echo "Bringing OpenSimulator up..."

echo "User-Service..."
/usr/bin/screen -S User-service -d -m -U mono OpenSim.Grid.UserServer.exe
sleep 5

echo "Asset-Service..."
/usr/bin/screen -S Asset-service -d -m -U mono OpenSim.Server.exe
sleep 10

echo "Grid-Service..."
/usr/bin/screen -S Grid-service -d -m -U mono OpenSim.Grid.GridServer.exe
sleep 5

echo "Messaging-Service..."
/usr/bin/screen -S Messaging-service -d -m -U mono OpenSim.Grid.MessagingServer.exe
sleep 5

echo "Region-Service..."
/usr/bin/screen -S Region-service -d -m -U mono OpenSim.exe
sleep 5

echo " "
echo " "
/usr/bin/screen -list