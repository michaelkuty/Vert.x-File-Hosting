<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * @package WordPress
 */

{%- for app in pillar.wordpress.apps %}
{%- if app_name == app.name %}

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', '{{ app.database.name }}');

/** MySQL database username */
define('DB_USER', '{{ app.database.user }}');

/** MySQL database password */
define('DB_PASSWORD', '{{ app.database.password }}');

/** MySQL hostname */
define('DB_HOST', '{{ app.database.host }}');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 */
define('AUTH_KEY',         '6;H^Z`B44@A|MfxA_T8u-Q}`}:Sx!|5z]I=n%|%Ze];nJ<OGwxhk5H,/Iyxz_.o%');
define('SECURE_AUTH_KEY',  'HZyf6bSB_^.oML*EUe)GfvD=0L&IWqo%2>:inZ={;Mhb%H28S`!.+9afZVITOrC,');
define('LOGGED_IN_KEY',    '.+-kuk(>it)aTY,J|+5PVs7_jCb{eS[qQ+-j)q|p4@;-1)<<;oby[,6ktq+ZDSI)');
define('NONCE_KEY',        '0<^|AMO|E|7CXI7VL1`t&Vc+cG47n?,O2jMIRd{:,d@hS7-BX``ur3K.!x{~R)iQ');
define('AUTH_SALT',        '*&Y:BN_3fCUg{x:AYow8&I;4CL8lc1--e4=@Vv%L=^e;)1`Q-5^(av^$$k8sR+-!');
define('SECURE_AUTH_SALT', ':m3>N,HgR/!Axrtic3oq[n-2X_-}3_f3k]y&1]V2$|31/ETfbP_B0r6a#I6!Da+y');
define('LOGGED_IN_SALT',   '(m%b^NC^X|9l6&,4P%dkH8;g9ZOnH4aL]z:$:q{+l?tjytiH-|qe)CvOc[bBW}Z@');
define('NONCE_SALT',       'OCX=(bzL5>sk_q+|kxfs}d,$3DkG-PE7Y P+CDKF1N 1ew%-n,9U ~ .?p>ggJa>');

/**
 * WordPress Database Table prefix.
 *
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
        define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

{%- endif %}
{%- endfor %}
