
{% if pillar.system.proxy is defined %}
export http_proxy=http://{{ pillar.system.proxy.host }}:{{ pillar.system.proxy.port }}/
export https_proxy=http://{{ pillar.system.proxy.host }}:{{ pillar.system.proxy.port }}/
{% endif %}