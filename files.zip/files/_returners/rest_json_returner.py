'''
Return data to a postgresql server

This is the default interface for returning data for the butter statd subsytem
'''

import logging

import urllib
import urllib2
import json

log = logging.getLogger(__name__)

__opts__ = {
    'RETURNER_API_HOST': 'admin1.htfs.info',
    'RETURNER_API_PORT': 80,
    'RETURNER_API_PATH': 'salt-ret',
}

def returner(ret):
    '''Return data to a JSON REST API'''

    url = 'http://%s/%s/' % (__opts__.get('RETURNER_API_HOST'), __opts__.get('RETURNER_API_PATH'))
    values = {
        'ret' : json.dumps(ret),
    }

    data = urllib.urlencode(values)
    req = urllib2.Request(url, data)
    conn = urllib2.urlopen(req)
    page = conn.read()
