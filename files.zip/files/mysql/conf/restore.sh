#!/bin/sh
{%- for app in pillar.mysql.databases %}

{%- if app_name == app.name %}

cd /srv/mysql/sites/{{ app.name }}

scp rsync@backup1.dev.mysql.cz:{{ app.data.database }} ./init.sql

mysql -h {{ app.database.host }} -u {{ app.database.user }} -p{{ app.database.password }} {{ app.database.name }} < ./init.sql

touch /srv/mysql/flags/{{ app.name }}-db-installed

{%- endif %}

{%- endfor %} 