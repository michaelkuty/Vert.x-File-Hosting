#!/bin/sh

DATE=$(date +%Y%m%d)

{%- for database in pillar.mysql.databases %}
mkdir -p /root/mysql/backup/{{ database.name }}
mysqldump --defaults-file=/etc/mysql/debian.cnf {{ database.name }} > /root/mysql/backup/{{ database.name }}/${DATE}.sql
cp /root/mysql/backup/{{ database.name }}/${DATE}.sql /root/mysql/backup/{{ database.name }}/last.sql
{%- endfor %}

# purge old dumps
find /root/mysql/backup/ -name "*.sql*" -mtime +8 -exec rm -vf {} \;