#!/bin/sh

DATE=$(date +%Y%m%d)

{%- for database in pillar.postgresql.databases %}
mkdir -p /root/postgresql/backup/{{ database.name }}
sudo -u postgres -H pg_dump {{ database.name }} > /root/postgresql/backup/{{ database.name }}/${DATE}.sql
cp /root/postgresql/backup/{{ database.name }}/${DATE}.sql /root/postgresql/backup/{{ database.name }}/last.sql
{%- endfor %}

# purge old dumps
find /root/postgresql/backup/ -name "*.sql*" -mtime +8 -exec rm -vf {} \;