
DO
$body$
BEGIN
    {%- for database in pillar.postgresql.databases %}
    IF NOT EXISTS (
        SELECT *
        FROM pg_catalog.pg_user
        WHERE usename = '{{ database.user }}')
        THEN CREATE ROLE {{ database.user }} LOGIN PASSWORD '{{ database.password }}';
    END IF;
    IF NOT EXISTS (
        SELECT *
        FROM pg_catalog.pg_user
        WHERE usename = '{{ database.user }}')
        THEN CREATE ROLE {{ database.user }} LOGIN PASSWORD '{{ database.password }}';
    END IF;
    {%- endfor %}
END
$body$

