
{%- for app in pillar.webcms.apps %}
{%- if app_name == app.name %}

DEFAULT_DATABASE = {
    {%- if app.database.engine == 'mysql' %}
    'ENGINE': 'django.db.backends.mysql',
    'PORT': '3306',
    'OPTIONS': { 'init_command': 'SET storage_engine=INNODB,character_set_connection=utf8,collation_connection=utf8_unicode_ci', },
    {% else %}
    'ENGINE': 'django.db.backends.postgresql_psycopg2',
    'PORT': '5432',
    {%- endif %}
    'HOST': '{{ app.database.host }}',
    'NAME': '{{ app.database.name }}',
    'PASSWORD': '{{ app.database.password }}',
    'USER': '{{ app.database.user }}'
}

DEFAULT_CACHE = {
    'BACKEND': 'django.core.cache.backends.memcached.MemcachedCache',
    'LOCATION': '{{ app.cache.host }}:11211',
    'TIMEOUT': 120,
    'KEY_PREFIX': '{{ app.cache.prefix }}'
}

DEFAULT_EMAIL = {
    'HOST': '{{ app.mail.host }}',
    'USER': '{{ app.mail.user }}',
    'PASSWORD': '{{ app.mail.password }}'
}

{%- endif %}
{%- endfor %}
