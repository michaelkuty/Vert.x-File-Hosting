#!/bin/sh

{%- for app in pillar.webcms.apps  %}
{%- if app.name == app_name %}
{%- if app.data is defined %}
scp -r rsync@{{ app.data.host }}:{{ app.data.path }}/* /srv/webcms/sites/{{ app.name }}/media
touch /root/webcms/flags/{{ app.name }}
{%- endif %}
{%- endif %}
{%- endfor %}
