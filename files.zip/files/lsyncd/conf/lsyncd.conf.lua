----
-- User configuration file for lsyncd.
--

settings {
  logfile = "/var/log/lsyncd/lsyncd.log",
  statusFile = "/tmp/lsyncd.status",
  insist = 1
}

{%- if pillar.lsyncd.syncs is defined %}
{%- for sync in pillar.lsyncd.syncs %}
{%- if sync.type == 'rsyncssh' %}
sync {
  default.rsyncssh,
  source="{{ sync.source }}",
  host="{{ sync.target.user }}@{{ sync.target.host }}",
  targetdir="{{ sync.target.directory }}/"
}
{%- endif %}
{%- endfor %}
{%- endif %}

{%- if pillar.webcms is defined %}
{%- for app in pillar.webcms.apps %}
{%- if app.backup is defined %}
{%- if app.backup %}
sync {
  default.rsyncssh,
  source="/srv/webcms/sites/{{ app.name }}/media",
  host="rsync@{{ pillar.lsyncd.sync_target }}",
  targetdir="{{ pillar.system.name }}/webcms/{{ app.name }}/",
  exclude={"/lib", "/theme", "/_cache"}
}
{%- endif %}
{%- endif %}
{%- endfor %}
{%- endif %}

{%- if pillar.redmine is defined %}
{%- for app in pillar.redmine.apps %}
{%- if app.backup is defined %}
{%- if app.backup %}
sync {
  default.rsyncssh,
  source="/srv/redmine/sites/{{ app.name }}/media",
  host="rsync@{{ pillar.lsyncd.sync_target }}",
  targetdir="{{ pillar.system.name }}/redmine/{{ app.name }}/",
  exclude={"/lib", "/theme", "/_cache"}
}
{%- endif %}
{%- endif %}
{%- endfor %}
{%- endif %}

{%- if pillar.mysql is defined %}
sync {
  default.rsyncssh,
  source="/root/mysql/backup",
  host="rsync@{{ pillar.lsyncd.sync_target }}",
  targetdir="{{ pillar.system.name }}/mysql/"
}
{%- endif %}

{%- if pillar.postgresql is defined %}
sync {
  default.rsyncssh,
  source="/root/postgresql/backup",
  host="rsync@{{ pillar.lsyncd.sync_target }}",
  targetdir="{{ pillar.system.name }}/postgresql/"
}
{%- endif %}
