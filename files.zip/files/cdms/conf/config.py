{% set app = pillar.cdms %}

DEFAULT_DATABASE = {
    {%- if app.database.engine == 'pyodbc' %}
    'ENGINE': 'sql_server.pyodb',
    'OPTIONS': {
        'host_is_server': True,
        'driver': 'FreeTDS',
        'dsn': '{{ app.database.dsn }}',
        'AutoCommit': 1
    },
    {% else %}
    'ENGINE': 'django.db.backends.postgresql_psycopg2',
    'PORT': '5432',
    {%- endif %}
    'HOST': '{{ app.database.host }}',
    'NAME': '{{ app.database.name }}',
    'PASSWORD': '{{ app.database.password }}',
    'USER': '{{ app.database.user }}'
}

DEFAULT_CACHE = {
    'BACKEND': 'django.core.cache.backends.memcached.MemcachedCache',
    'LOCATION': '{{ app.cache.host }}:11211',
    'TIMEOUT': 120,
    'KEY_PREFIX': '{{ app.cache.prefix }}'
}

DEFAULT_EMAIL = {
    'HOST': '{{ app.mail.host }}',
    {%- if app.mail.user is defined %}
    'USER': '{{ app.mail.user }}',
    {%- endif %}
    {%- if app.mail.user is defined %}
    'PASSWORD': '{{ app.mail.password }}'
    {%- endif %}
}

DEFAULT_ENVIRONMENT = '{{ pillar.system.environment }}'
